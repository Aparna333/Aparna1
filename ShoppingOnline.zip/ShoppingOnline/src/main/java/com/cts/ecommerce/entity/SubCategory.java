package com.cts.ecommerce.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class SubCategory  implements Serializable{
	@Id
	@GeneratedValue
	@Column(name="sub_id")
	private int subCategoryId;
	@Column(name="sub_name")
	private String subCategoryName;
	private int CategoryId;
	@Column(name="sub_dtls")
	private String subCategoryDetails;
	@Column(name="GST %")
	private float gst;
	
	

}
