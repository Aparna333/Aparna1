package com.cts.ecommerce.entity;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Category implements Serializable {
	@Id
	@GeneratedValue
	private int categoryId;
	private String categotyName;
	private String CategoryDetails;
	
	public Category() {
		
	}

	public Category(int categoryId, String categotyName, String categoryDetails) {
		super();
		this.categoryId = categoryId;
		this.categotyName = categotyName;
		CategoryDetails = categoryDetails;
	}

	public int getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}

	public String getCategotyName() {
		return categotyName;
	}

	public void setCategotyName(String categotyName) {
		this.categotyName = categotyName;
	}

	public String getCategoryDetails() {
		return CategoryDetails;
	}

	public void setCategoryDetails(String categoryDetails) {
		CategoryDetails = categoryDetails;
	}

	@Override
	public String toString() {
		return "Category [categoryId=" + categoryId + ", categotyName=" + categotyName + ", CategoryDetails="
				+ CategoryDetails + "]";
	}
	
	

}
