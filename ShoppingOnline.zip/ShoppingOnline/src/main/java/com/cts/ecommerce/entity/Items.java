package com.cts.ecommerce.entity;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Items implements Serializable{
	    @Id
        private int itemId;
        private int categoryId;
        //private int 
}
