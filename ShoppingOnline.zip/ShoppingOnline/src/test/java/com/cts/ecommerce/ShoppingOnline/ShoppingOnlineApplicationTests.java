package com.cts.ecommerce.ShoppingOnline;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShoppingOnlineApplicationTests {

	@Test
	void contextLoads() {
	}

}
