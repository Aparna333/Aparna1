package com.cts.hibernate.HibernateBasic;

import java.io.Serializable;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;

import com.cts.hibernate.model.Employee;
//import com.cts.hibernate.model.Employee;
import com.cts.hibernate.model.OrderItem;

public class App 
{
    public static void main( String[] args )
    {
    	/*Configuration configuration=new Configuration().configure();
        StandardServiceRegistryBuilder builder=new StandardServiceRegistryBuilder()
        		         .applySettings(configuration.getProperties());
        SessionFactory factory=configuration.buildSessionFactory(builder.build());
        Session session=factory.openSession();*/
    	
    	Configuration configuration=new Configuration().configure();
    	SessionFactory sf=configuration.buildSessionFactory();
    	Session session=sf.openSession();

    	//List list= session.createQuery("FROM OrderItem").list(); 
         //for (Iterator iterator1 =list.iterator(); iterator1.hasNext();){
           // OrderItem e = (OrderItem) iterator1.next(); 
    	//Iterator it=list.iterator();

		/*
		 * while(it.hasNext()) { OrderItem e = (OrderItem)it.next();
		 * System.out.println(e); }
		 */
    	/*Query q=session.createQuery("FROM OrderItem");
         List l=q.list();

 		Iterator it=l.iterator();

 		while(it.hasNext())
 		{
 			 OrderItem e = (OrderItem)it.next();
 			System.out.println(e);
 		}*/
    	
    	//Query q1=session.getNamedQuery("retriveall");
    	//q1.setFirstResult(0);
    	//System.out.println(q1.list());
    	/*OrderItem order=new OrderItem();
    	String hql="from OrderItem o where o.productId=?";
    	Query q=session.createQuery(hql);
    	q.setLong(0, 1);
    	List list=q.list();
    	System.out.println(list);*/   //Positional parameter setString 
    	
    	
    	/*OrderItem order=new OrderItem();
    	order.setOrderId(1);
    	String hql="from OrderItem o where o.productId=:productId";
    	List list=session.createQuery(hql).setProperties(order).list();
    	System.out.println(list);*/     //named parameter
    	
    	
    	/* String hql="from OrderItem o where o.orderId=?";
         Query q=session.createQuery(hql);
     	q.setParameter(0, 1);
     	List list=q.list();
     	System.out.println(list);*/  //positional parameter
    	
    	/*Query query=session.createQuery("from OrderItem o where o.orderId=:orderid");
    	query.setParameter("orderid", 1);
    	List list=query.list();
    	System.out.println(list);*/  //named parameter

    	/*String qry="select o.totat FROM OrderItem o";
    	Query query=session.createQuery(qry);
    	 List<OrderItem> list=query.list();
    	 System.out.println(list);*/
    	 
		/* OrderItem order=new OrderItem(1, 55, 6, 700, 897.9f);
		 Transaction t=session.beginTransaction();
		 session.save(order); 
		 t.commit();*/
		 
    	
    	
    	//Employee emp=(Employee) session.get(Employee.class,1119);// id is absent in DB,null passed to Session.evict()
    	Employee emp=(Employee) session.load(Employee.class,1112);// id is absent in DB, runtimeException
    	System.out.println(emp);
    	//Transaction t=session.beginTransaction();
    	//session.evict(emp);
    	//emp.setEmpDesig("update");
    	//session.update(emp);
    	//session.save(emp);
    	//session.delete(emp);
    	//t.commit();
    	
    
        /*Employee emp=new Employee(1112,"anju","manager");
        session.beginTransaction();
        Serializable se=session.save(emp);
        emp.setEmpDesig("mngr");
        session.getTransaction().commit();
        session.close();*/
    }
}
