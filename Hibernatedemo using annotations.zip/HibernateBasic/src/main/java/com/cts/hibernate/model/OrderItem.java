package com.cts.hibernate.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name = "order_item")
@NamedQuery(name = "retriveall",query = "FROM OrderItem")
public class OrderItem {
	 @Id
	 @Column(name = "order_id")
	private int orderId;
	 @Column(name = "product_id")
	private int productId;
	 @Column(name = "product_count")
	private int productCount;
	private int totat;
	 @Column(name = "product_price")
	private float productPrice;
  
	 public OrderItem() {
		
	}

	public OrderItem(int orderId, int productId, int productCount, int totat, float productPrice) {
		this.orderId = orderId;
		this.productId = productId;
		this.productCount = productCount;
		this.totat = totat;
		this.productPrice = productPrice;
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public int getProductCount() {
		return productCount;
	}

	public void setProductCount(int productCount) {
		this.productCount = productCount;
	}

	public int getTotat() {
		return totat;
	}

	public void setTotat(int totat) {
		this.totat = totat;
	}

	public float getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(float productPrice) {
		this.productPrice = productPrice;
	}

	@Override
	public String toString() {
		return "OrderItem [orderId=" + orderId + ", productId=" + productId + ", productCount=" + productCount
				+ ", totat=" + totat + ", productPrice=" + productPrice + "]";
	}
}
