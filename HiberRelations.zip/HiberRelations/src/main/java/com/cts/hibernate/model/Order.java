package com.cts.hibernate.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;


@Entity
public class Order implements Serializable{
	
	@Id
	@GeneratedValue
	private int orderId;
	private String orderDes;
	
	@OneToMany
	private List<OrderItem> oi=new ArrayList<OrderItem>();
	
	
	public Order() {
		// TODO Auto-generated constructor stub
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public void setOrderDes(String orderDes) {
		this.orderDes = orderDes;
	}
	public String getOrderDes() {
		return orderDes;
	}
	public int getOrderId() {
		return orderId;
	}
	
	
	public Order(String orderDes) {
		super();
		this.orderId = orderId;
		this.orderDes = orderDes;
	}
	@Override
	public String toString() {
		return "Order [orderId=" + orderId + ", orderDes=" + orderDes + "]";
	}
	public void setOi(OrderItem oi1) {
		// TODO Auto-generated method stub
		
	}
	

}
