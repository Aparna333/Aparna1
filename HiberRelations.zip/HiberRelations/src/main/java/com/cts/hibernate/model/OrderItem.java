package com.cts.hibernate.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
public class OrderItem implements Serializable{
	@Id
	@GeneratedValue
	private int orderItemId;
	
	private int orderList;
	
	//@OneToMany
	@JoinColumn
	private Order o;
	
	public OrderItem() {
		// TODO Auto-generated constructor stub
	}
	public int getOrderItemId() {
		return orderItemId;
	}
	public void setOrderItemId(int orderItemId) {
		this.orderItemId = orderItemId;
	}
	public int getOrderList() {
		return orderList;
	}
	public void setOrderList(int orderList) {
		this.orderList = orderList;
	}
	public OrderItem(int orderList) {
		super();
		this.orderItemId = orderItemId;
		this.orderList = orderList;
	}
	@Override
	public String toString() {
		return "OrderItem [orderItemId=" + orderItemId + ", orderList=" + orderList + "]";
	}
	
}
