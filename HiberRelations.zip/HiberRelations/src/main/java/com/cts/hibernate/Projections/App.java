package com.cts.hibernate.Projections;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;

import com.cts.hibernate.model.Order;
import com.cts.hibernate.model.OrderItem;



public class App 
{
    public static void main( String[] args )
    {
    	/*Configuration configuration=new Configuration().configure();
       StandardServiceRegistryBuilder builder=new StandardServiceRegistryBuilder()
    		                   .applySettings(configuration.getProperties());
       SessionFactory factory=configuration.buildSessionFactory(builder.build());
       Session session=factory.openSession();*/
       
       Configuration configuration=new Configuration().configure();
       SessionFactory factory=configuration.buildSessionFactory();
       Session session=factory.openSession();
       
      Order o1=new Order();
       o1.setOrderDes("first mobile");
       Order o2=new Order();
       o1.setOrderDes("second mobile");
       OrderItem oi1=new OrderItem();
       oi1.setOrderList(5);
       o1.setOi(oi1);
       Transaction tx=session.beginTransaction();
       session.save(o1);
       session.save(o2);
       session.save(oi1);
       tx.commit();
       session.close();
    }
}
