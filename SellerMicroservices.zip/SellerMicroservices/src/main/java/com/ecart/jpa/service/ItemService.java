package com.ecart.jpa.service;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ecart.jpa.entity.Items;
import com.ecart.jpa.repository.ItemRepository;

@Service
public class ItemService {
	@Autowired
	private ItemRepository itemRepository;
	
	public Items save(@Valid Items item) {
		
		return itemRepository.save(item);
	}

}
