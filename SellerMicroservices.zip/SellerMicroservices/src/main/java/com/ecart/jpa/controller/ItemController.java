package com.ecart.jpa.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.ecart.jpa.entity.Items;
import com.ecart.jpa.service.ItemService;
import com.ecart.jpa.service.SellerService;

@RestController
public class ItemController {
     
	@Autowired
	private ItemService itemService;
	
	@PostMapping(name = "/seller/{sellerId}/items", produces = "application/json")
    public Items addItem(@PathVariable (value = "sellerId") Long sellerId,
                                 @Valid @RequestBody Items item) {
     return itemService.addItem(sellerId, item);
    }
  
	@PutMapping("/sellers/{sellerId}/items/{itemId}")
    public Items updateItem(@PathVariable (value = "itemId") Long sellerId,
                                 @Valid @RequestBody Items items) {
       return itemService.updateItem(sellerId, items);
    }
	
	@DeleteMapping(value = "/{itemId}/delete")
	public String deleteItem(@PathVariable("itemId") Long itemId) {
		return itemService.deleteItemById(itemId);
	}
	 
    @GetMapping(value = "/{sellerId}/getAll")
	public List<Items> getAllItems(@PathVariable("sellerId")Long sellerId) {
	return itemService.getAllItems(sellerId);
	}
    @DeleteMapping(value = "/{sellerId}/deleteall")
	public void deleteAll(@PathVariable("sellerId") Long sellerId) {
		itemService.deleteAll(sellerId);
	}

}