package com.ecart.jpa.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.ecart.jpa.entity.Items;
import com.ecart.jpa.repository.ItemRepository;
import com.ecart.jpa.service.ItemService;

@RestController
public class ItemController {
     
	@Autowired
	private ItemService service;
	
	@RequestMapping(path = "/items",method = RequestMethod.POST)
	public Items addItem(@Valid @RequestBody Items item) {
		
	return service.save(item);
	}
    
}