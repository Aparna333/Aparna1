package com.cts.springbootjpa.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cts.springbootjpa.Person;


public interface IPersonService{

	 List<Person> getAllPersons();
	
	 Person getByPersonName(String name); 
	 
//	 Person findUsingNameAddress(String name, String addr);
	 
	 Integer createOrUpdate(Person person);
	 
	 void deleteById(Integer personId);
	 
	 Person update (Person person);
	 
	 Person updateAddr(Person person);

	
	
}
