package com.cts.springbootjpa.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.springbootjpa.Person;
import com.cts.springbootjpa.dao.IPersonDao;
import com.cts.springbootjpa.dao.IPersonService;

@Service
public class PersonServiceImpl implements IPersonService {

	@Autowired
	private IPersonDao dao; //entity mgr factory
	
	@Override
	public List<Person> getAllPersons() {
	
		return dao.findAll();
				
	}

	@Override
	public Person getByPersonName(String name) {
		// TODO Auto-generated method stub
		return dao.findByPersonName(name);
	}

	@Override
	public Integer createOrUpdate(Person person) {
		Person p =(Person)dao.save(person);
		return p.getPersonId();
	}

	@Override
	public void deleteById(Integer personId) {
		Optional<Person> person = dao.findById(personId);
		
		if(person.isPresent()) {
		dao.deleteById(personId);
		}
		
	}

	@Override
	public Person update(Person person) {
		Optional<Person> per = dao.findById(person.getPersonId());
		Person newPerson = null;
		if(per.isPresent()) {
			newPerson = per.get();
			newPerson.setPersonName(person.getPersonName());
			newPerson.setAddr(person.getAddr());
			newPerson = dao.save(newPerson);
		}
		return newPerson;
	}

	@Override
	public Person updateAddr(Person person) {
		
		Optional<Person> per = dao.findById(person.getPersonId());
		Person newPerson = null;
		if(per.isPresent()) {
			newPerson = per.get();
			newPerson.setAddr(person.getAddr());
			newPerson = dao.save(newPerson);
		}
		return newPerson;
		
	}

//	@Override
//	public Person findUsingNameAddress(String name, String ad) {
//		// TODO Auto-generated method stub
//		return dao.findUsingNameAddress(name, ad);
//	}
	
	

}
