package com.cts.springbootjpa.dao;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cts.springbootjpa.Person;

@Repository
public interface IPersonDao  extends JpaRepository<Person, Integer> {
	
	@Query(value = "FROM Person p WHERE p.personName=:pname")
	public Person findByPersonName(@Param("pname") String name);
	
//	@Query(value = "FROM Person p WHERE p.personName=:pname AND p.addr:addr")
//	public Person findUsingNameAddress(@Param("pname") String name, @Param("addr") String ad);
//	
	
}
