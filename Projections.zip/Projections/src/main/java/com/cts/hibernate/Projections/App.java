package com.cts.hibernate.Projections;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;

import com.cts.hibernate.model.Products;

public class App 
{
    public static void main( String[] args )
    {
    	/*Configuration configuration=new Configuration().configure();
       StandardServiceRegistryBuilder builder=new StandardServiceRegistryBuilder()
    		                   .applySettings(configuration.getProperties());
       SessionFactory factory=configuration.buildSessionFactory(builder.build());
       Session session=factory.openSession();*/
       
       Configuration configuration=new Configuration().configure();
       SessionFactory factory=configuration.buildSessionFactory();
       Session session=factory.openSession();
       
    //  Products prod=new Products(21,"Moblie", 890.9f, 4);
       Products prod1=(Products)session.get(Products.class, 21);
       Transaction t=session.beginTransaction();
       session.save(prod1);
       t.commit();
       System.out.println(prod1);
       
       Criteria crit = session.createCriteria(Products.class);
       crit.add(Restrictions.eq("prodName","anu"));
       List<Products> results = crit.list();
       
       Iterator it=results.iterator();
       while(it.hasNext()) {
    	   Products p=(Products)it.next();
    	   System.out.println(p);
    	   
       }
    }
}
