package com.cts.maven.Dao;

import java.util.HashMap;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.cts.maven.model.Product;

@Repository
public class Dao {
	  
	  HashMap<Integer,Product> map=new HashMap<>();
	     public int addProduct(Product product) {
		map.put(product.getProdId(),product);
		 return product.getProdId();
	    	  
	      }

}
