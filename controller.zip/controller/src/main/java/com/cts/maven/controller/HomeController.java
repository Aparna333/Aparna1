package com.cts.maven.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.method.annotation.ViewNameMethodReturnValueHandler;

import com.cts.maven.model.Product;
import com.cts.maven.service.Service;

@Controller
public class HomeController {
	@Autowired
	Service serv=null;
	
	@RequestMapping("/")
	public String getProduct(Model m) {
		Product p=new Product();
		m.addAttribute("prod", p);
		return "index";
	}
	/*@RequestMapping(value= "Product", method=RequestMethod.POST)
	public ModelAndView getProcessinfo(Model m, @ModelAttribute("prod") Product product ) {
		ModelAndView mav=new ModelAndView("result");
		mav.addObject("msg", product);
		return mav;}*/
		
	@RequestMapping(value= "Product", method=RequestMethod.POST)
	public ModelAndView getProcessinfo(@Valid @ModelAttribute("prod") Product product,BindingResult br ) {
		String path=null;
		ModelAndView mav=new ModelAndView();
		if(br.hasErrors()) {
			path="index";
		}
		else {
		 path="result";
		 int pid=serv.addProduct(product);
	     mav.addObject("msg", "Product data with" +pid+ "stored sucessfully!!!!"); 
	}
		mav.setViewName(path);
		return mav;
		
}
}	


