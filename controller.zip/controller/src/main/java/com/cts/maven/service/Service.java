package com.cts.maven.service;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cts.maven.Dao.Dao;
import com.cts.maven.model.Product;

@org.springframework.stereotype.Service
public class Service {
	@Autowired
	Dao pDao;
      public int addProduct(Product product) {
		pDao.addProduct(product);
		return product.getProdId();
    	  
      }
    
}
