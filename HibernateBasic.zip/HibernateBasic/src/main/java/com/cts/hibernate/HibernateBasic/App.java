package com.cts.hibernate.HibernateBasic;

import java.io.Serializable;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;

import com.cts.hibernate.model.Employee;

public class App 
{
    public static void main( String[] args )
    {
    	/*Configuration configuration=new Configuration().configure();
        StandardServiceRegistryBuilder builder=new StandardServiceRegistryBuilder()
        		         .applySettings(configuration.getProperties());
        SessionFactory factory=configuration.buildSessionFactory(builder.build());
        Session session=factory.openSession();*/
    	
    	Configuration configuration=new Configuration().configure();
    	SessionFactory sf=configuration.buildSessionFactory();
    	Session session=sf.openSession();
    			
    	Employee emp=(Employee) session.get(Employee.class,1111);
    	//System.out.println(emp);
    	session.beginTransaction();
    	//session.evict(emp);
    	//emp.setEmpDesig("update");
    	//session.update(emp);
    	//session.save(emp);
    	session.delete(emp);
    	session.getTransaction().commit();
    	
    
        /*Employee emp=new Employee(1112,"anju","manager");
        session.beginTransaction();
        Serializable se=session.save(emp);
        emp.setEmpDesig("mngr");
        session.getTransaction().commit();
        session.close();*/
    }
}
