/* Aparna */
package com.cts.maven.Dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.cts.maven.model.Product;
@Repository
public class ProductDaojdbc extends ProductDao{
	@Autowired
	private DataSource ds;
	private JdbcTemplate jdbc;
	
	//public ProductDaojdbc(DataSource dataSource) {
		
	
	public void setJdbc(JdbcTemplate jdbc) {
		this.jdbc = jdbc;
	}
	
	public int addProduct(Product product) {
		JdbcTemplate jdbc=new JdbcTemplate(ds);
		int storedStatus=jdbc.update("INSERT INTO product values(?,?,?,?)",new Object[] 
				{product.getProdId(),product.getProdName(),product.getQuantity(),product.getPrice()});
		System.out.println(storedStatus);
		return product.getProdId();
	}
	
	public Product getById(int prodId) {
		JdbcTemplate jdbc=new JdbcTemplate(ds);
		String sql = "SELECT * FROM product WHERE prodId=?";
		Product product = (Product)jdbc.queryForObject(sql, new Object[] {prodId},
				                                        new RowMapper<Product>() {
			@Override
			public Product mapRow(ResultSet rs, int rowNum) throws SQLException {

				Product product = new Product();

				product.setProdId(rs.getInt(1));
				product.setProdName(rs.getString(2));
				product.setQuantity(rs.getInt(3));
				product.setPrice(rs.getFloat(4));

				return getById(prodId);
			}
	    }); 
		return product;
	}
	public int updateProduct(Product product) {
	       JdbcTemplate jdbc = new JdbcTemplate(ds);
			String sql = "UPDATE product SET prodName=?,quantity=?,price=? WHERE prodId =?";
			int count = jdbc.update(sql,new Object[] 
					{product.getProdId(),product.getProdName(),product.getQuantity(),product.getPrice()});
			return count;
	}
	public int deleteProduct(int prodId) {
		JdbcTemplate jdbc=new JdbcTemplate(ds);
		String sql = "DELETE FROM product WHERE prodId=?";
	    int count=jdbc.update(sql, prodId);
		return count;
	}
	
	public List<Product> getAllProduct(Product product) {
		JdbcTemplate jdbc=new JdbcTemplate(ds);
		String sql = "SELECT * FROM product";
	    List<Product> li = jdbc.query(sql, new RowMapper<Product>() {
	 
	        @Override
	        public Product mapRow(ResultSet rs, int rowNum) throws SQLException {
	            Product product = new Product();
	 
	            product.setProdId(rs.getInt("prodId"));
	            product.setProdName(rs.getString("prodName"));
	            product.setQuantity(rs.getInt("quantity"));
	            product.setPrice(rs.getFloat("price"));
	            return product;
	        }
	 
	    });
	    return li;
	}

}

