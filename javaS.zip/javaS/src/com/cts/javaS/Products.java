package com.cts.javaS;

public class Products {

	public void AddProduct(Products p) {
		// TODO Auto-generated method stub
		
	}

	public void FindProductById() {
		// TODO Auto-generated method stub
		
	}

	public void GetAllProductData() {
		// TODO Auto-generated method stub
		
	}

}
