/*Aparna*/
package com.cts.javaS;

import java.util.Random;
import java.util.Scanner;

public class UserInterface {
	static Scanner scan=new Scanner(System.in);
	static Service empServ=null;
		
		public static void main(String f[]){
			System.out.println("Welcome, Admin!!!");
			System.out.printf("1. add product \n2. find product by id\n");
			System.out.println("3. get all products info");
			System.out.println("enter option: ");
			int choice=scan.nextInt();
			switch(choice){
			case 1:
					empServ=new Service();
					System.out.println("enter product info:");
					Product pdt=new Product();
					pdt.setPrice(scan.nextFloat());
					pdt.setQuantity(scan.nextInt());
					pdt.setProdId(new Random().nextInt(10909));
					pdt.setProdName(scan.next());
					int eid=empServ.addProduct(pdt);
					System.out.println(eid>0?eid+" is stored successfully!!!!":"not stored");
				break;
			case 2:
				empServ=new Service();
				Product d=empServ.getProductById(1009);
				System.out.println(d==null?"no data matching the id":d);
				break;
			case 3:
				
				break;
			default:
				break;
				
			}
		}
	

	}


