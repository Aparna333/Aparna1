import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BuyerlogoutComponent } from './buyerlogout.component';

describe('BuyerlogoutComponent', () => {
  let component: BuyerlogoutComponent;
  let fixture: ComponentFixture<BuyerlogoutComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BuyerlogoutComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BuyerlogoutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
