import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';


@Component({
  selector: 'app-transactionlist',
  templateUrl: './transactionlist.component.html',
  styleUrls: ['./transactionlist.component.css']
})
export class TransactionlistComponent implements OnInit {

  constructor(private transactionService:ProductService) { }
  buyer:any;
  transaction:any;
  transactionType:String;
    price:number;
    totalAmount:number;
  ngOnInit(): void {
     this.buyer=window.localStorage.getItem('buyerId');
    this.transactionService.getTransaction(this.buyer).subscribe(transaction=>this.transaction=transaction)
  }

}
