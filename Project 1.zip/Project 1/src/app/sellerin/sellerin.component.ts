import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sellerin',
  templateUrl: './sellerin.component.html',
  styleUrls: ['./sellerin.component.css']
})
export class SellerinComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
