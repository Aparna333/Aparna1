import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-purchaselist',
  templateUrl: './purchaselist.component.html',
  styleUrls: ['./purchaselist.component.css']
})
export class PurchaselistComponent implements OnInit {

  constructor(private purchaseService:ProductService) { }
  buyer:any;
  purchase:any;
  purchaseId:number;
  numberOfItems:number;
  ngOnInit(): void {
    this.buyer=window.localStorage.getItem('buyerId');
    this.purchaseService.getAllItems(this.buyer).subscribe(purchase=>this.purchase=purchase);
  }

}
