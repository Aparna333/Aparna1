export class Item{
    itemId:number;
    category:number;
    subCategory:number;
    price:number;
    manufacturer: String;
    itemName:String;
    description:String;
    stockNumber:number;
    remarks:String;
   
}
export class Seller{
  username:String;
	 password:String;
	 companyName:String;
	 companyDetails:String;
     postalAddress:String;
	 website:String;
     email:String;
     gstIN:number;
     contactNumber:String;   
}
  export class Cart {
    cartId:number;
    itemId:number;
    description:String;
    quantity:number;
    price:number;
    totalPrice:number;
   }
   export class Buyer{
     username:String;
     password:String;
     email:String;
     mobileNumber:String;
  }
  export class ViewCart{
    cartId:number;
    itemId:number;
    quantity:number;
    price:number;
    totalPrice:number;
  }
  export class Transactions{
    transactionType:String;
    createDate:String;
    price:number;
    totalAmount:number;
  }
export class PurchaseHistory{
  purchaseId:number;
  numberOfItems:number;
}