import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SellerlogoutComponent } from './sellerlogout.component';

describe('SellerlogoutComponent', () => {
  let component: SellerlogoutComponent;
  let fixture: ComponentFixture<SellerlogoutComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SellerlogoutComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SellerlogoutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
