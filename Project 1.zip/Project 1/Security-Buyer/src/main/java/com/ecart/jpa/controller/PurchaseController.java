package com.ecart.jpa.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ecart.jpa.entity.PurchaseHistory;
import com.ecart.jpa.service.PurchaseService;


@CrossOrigin("*")
@RequestMapping("/cart")
@RestController
public class PurchaseController {
	
    
	@Autowired
	private PurchaseService purchaseService;
	
	@GetMapping(value = "/{buyerId}/getPurchase")
	public List<PurchaseHistory> getAllPurchases(@PathVariable("buyerId")Long buyerId) {
	return purchaseService.getAllPurchases(buyerId);
	}
}
