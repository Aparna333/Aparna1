package com.ecart.jpa.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.ecart.jpa.entity.PurchaseHistory;


@Repository
public interface PurchaseRepository extends JpaRepository<PurchaseHistory, Long> {
    
	@Transactional
	@Modifying
	@Query(value = "SELECT * FROM purchase_history WHERE purchase_history.buyer_id = :buyerId" ,nativeQuery = true)
	public List<PurchaseHistory> getAll(@Param("buyerId")Long buyerId);
	
}
