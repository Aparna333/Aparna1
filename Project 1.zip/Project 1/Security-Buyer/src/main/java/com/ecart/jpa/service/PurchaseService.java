package com.ecart.jpa.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ecart.jpa.entity.PurchaseHistory;
import com.ecart.jpa.repository.PurchaseRepository;

@Service
public class PurchaseService {
	
	@Autowired
	private PurchaseRepository purchaseRepository;

	public List<PurchaseHistory> getAllPurchases(Long buyerId) {
		
		return purchaseRepository.getAll(buyerId);
	}

}
