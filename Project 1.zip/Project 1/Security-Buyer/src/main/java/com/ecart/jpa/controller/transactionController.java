package com.ecart.jpa.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ecart.jpa.entity.Transactions;
import com.ecart.jpa.service.TransactionService;

@CrossOrigin("*")
@RestController
@RequestMapping("/cart")
public class transactionController {

	@Autowired
	private TransactionService transactionService;
	
	@GetMapping(value = "/{buyerId}/getTransactions")
	public List<Transactions> getAllTransactions(@PathVariable("buyerId")Long buyerId) {
	return transactionService.getAllTransactions(buyerId);
	}
}
