package com.ecart.jpa.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.ecart.jpa.entity.Transactions;

@Repository
public interface TransactionRepository extends JpaRepository<Transactions, Long> {
	@Transactional
	@Modifying
	@Query(value = "SELECT * FROM transactions WHERE transactions.buyer_id= :buyerId" ,nativeQuery = true)
	public List<Transactions> getTransactions(@Param("buyerId")Long buyerId);
	
}
