package com.cts.api.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
//import org.apache.catalina.tribes.tipis.AbstractReplicatedMap.MapEntry;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MyRestController {
	
	Map<Integer,Product> map=new HashMap<>();
	List<Product> list=new ArrayList<>();

	public MyRestController() {
		
		map.put(1011,(new Product(1011,"tv",6,988)));
		map.put(1012,(new Product(1012,"Ac",6,498)));
		map.put(1013,(new Product(1013,"Mobile",6,435)));
		
		list.add(new Product(1011,"tv",6,998));
		list.add(new Product(1012,"Ac",6,498));
		list.add(new Product(1013,"Mobile",6,435));
	}
	@RequestMapping("/data")
	public Map<Integer,Product> displayProduct() {

		return map;
	}
	@RequestMapping("/jsondata")
	public List<Product> findbyId() {

		return list;
	}
	@RequestMapping(value="data/{pid}",method=RequestMethod.GET)
	public Product displayProduct1(@PathVariable("pid") int id ) {

		return map.get(id);
	}	
	@RequestMapping("/jsondata1")
	public ResponseEntity<List<Product>> findbyId1(@RequestBody Product product) {

		return ResponseEntity.ok().header("").body(list);
	}
}