package com.cts.streams;

import java.awt.List;
import java.util.ArrayList;

public class Emp {

	
	public static void main(String[] args) {
		ArrayList<Employee> emplist = new ArrayList<>();
		emplist.add(new Employee(1011, "ajay", 7500,"manager","ch"));
		emplist.add(new Employee(1011, "ajay", 7500,"manager","ch"));
		emplist.add(new Employee(1011, "ajay", 7500,"manager","ch"));
		emplist.add(new Employee(1011, "ajay", 7500,"manager","ch"));
	}

}

class Employee{
	private int empId;
	private String empName;
	private double Salary;
	private String design;
	private String city;
	
	public Employee(int i, String string, int j, String string2, String string3) {
		// TODO Auto-generated constructor stub
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public double getSalary() {
		return Salary;
	}
	public void setSalary(double salary) {
		Salary = salary;
	}
	public String getDesign() {
		return design;
	}
	public void setDesign(String design) {
		this.design = design;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	
}