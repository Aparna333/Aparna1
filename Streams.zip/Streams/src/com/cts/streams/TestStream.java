package com.cts.streams;

import java.sql.Date;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class TestStream {

	public static void main(String[] args) {
		Stream<String> streamEmpty=Stream.empty();
		System.out.println("Stream is empty!!");
		
	  //Stream<Integer> stream = Stream.of(1,2,5,8,9);
		//stream.forEach(p -> System.out.println(p));
		Stream<Integer> stream1= Stream.of(new Integer[]{1,2,5,8,9});
		stream1.forEach(p -> System.out.println(p));
		//ArrayList<Integer> arrayList = TestStream.collect(Collectors .toCollection(ArrayList::new));
			//System.out.println(arrayList);
		  List<Integer> list1 = Arrays.asList(3,2,5,8,9);
		List<Integer> square = list1.stream().map(x -> x*x). 
                collect(Collectors.toList());
		System.out.println(square);
		Integer var = list1.stream().min(Integer::compare).get();
		System.out.println(var);
		
		int[] integers = new int[] {20, 98, 12, 7, 35};
		int min = Arrays.stream(integers).min().getAsInt();
		int max = Arrays.stream(integers).max().getAsInt();
		
		System.out.println(min);
		System.out.println(max);
		
		//String[] arr = new String[]{"a", "b", "c"};
		//Stream<String> streamOfArrayFull = Arrays.stream(arr);
		
		/*System.out.println(streamOfArrayFull);
		Stream<String> streamOfArrayPart = Arrays.stream(arr, 1, 3);
		System.out.println(streamOfArrayPart);
		
		
		Stream<String> streamOfArray=Stream.of("a","b","c");
		System.out.println(streamOfArray);

*/
		String[] array = { "GeeksforGeeks", "GeeksQuiz" }; 
		
		Optional<String> MIN = Arrays.stream(array).min((str1, str2) ->  
		Character.compare(str1.charAt(str1.length() - 1),  
				str2.charAt(str2.length() - 1))); 
		if (MIN.isPresent())  
			System.out.println(MIN.get());  
		else
			System.out.println("null"); 
		
		//Stream<Date> stream = Stream.generate(() -> { return new Date(min, min, max); });
       // stream.forEach(p -> System.out.println(p));
		 Stream<String> stream = Stream.of("A$B$C".split("\\$"));
	        stream.forEach(p -> System.out.println(p));
}

	private static ArrayList<Integer> collect(Collector<Object, ?, Collection<Object>> collection) {
		// TODO Auto-generated method stub
		return null;
	}
	}

