package com.cts.maven.jdbs;

import org.springframework.beans.factory.annotation.Autowired;

import antlr.collections.List;


@org.springframework.stereotype.Service
public class Service {
	@Autowired
	ProductDao pDao;
      public int addProduct(Product product) {
		pDao.addProduct(product);
		return product.getProdId();
    	  
      }
	public List getAllProducts() {
		// TODO Auto-generated method stub
		return null;
	}
	public Product getProductById(int nextInt) {
		// TODO Auto-generated method stub
		return null;
	}
    
}
