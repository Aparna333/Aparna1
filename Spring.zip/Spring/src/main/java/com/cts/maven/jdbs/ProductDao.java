package com.cts.maven.jdbs;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class ProductDao {
	@Autowired
	private DataSource ds;
	private JdbcTemplate jdbc;
	public int addProduct(Product product) {
		int storedStatus=jdbc.update("INSERT INTO product values(?,?,?,?)",new Object[] {product.getProdId(),product.getProdName(),product.getQuantity(),product.getPrice()});
		System.out.println(storedStatus);
		return product.getProdId();

	}
}

