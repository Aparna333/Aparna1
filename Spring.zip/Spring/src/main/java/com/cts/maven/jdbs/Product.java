package com.cts.maven.jdbs;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.annotations.NotFound;

public class Product {
	private int prodId;
	 @NotFound
	  @Size(min=3, max=10, message="size is not matched")
     private String prodName;
	  @NotNull
     private int quantity;
     private float price;
     
     public Product(int prodId, String prodName, int quantity, int price) {
 		this.prodId = prodId;
 		this.prodName = prodName;
 		this.quantity = quantity;
 		this.price = price;
 	}
	public int getProdId() {
		return prodId;
	}
	public void setProdId(int prodId) {
		this.prodId = prodId;
	}
	public String getProdName() {
		return prodName;
	}
	public void setProdName(String prodName) {
		this.prodName = prodName;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price =price;
	}
     
	public Product() {
		System.out.println("object created!!");
	}
      
	 @Override
		public String toString() {
			return "Product [prodId=" + prodId + ", prodName=" + prodName + ", quantity=" + quantity + ", price=" + price
					+ "]";
	 }
}
