package com.cts.ecommerce.service;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cts.ecommerce.entity.Buyer;
import com.cts.ecommerce.entity.Person;


public interface IBuyerService{

	public  List<Buyer> getAllBuyers();
	
	public Buyer getByBuyerName(String name); 
	 
//	 Person findUsingNameAddress(String name, String addr);
	 
	  public Integer createOrUpdate(Buyer buyer);
	 
	  public void deleteById(Integer buyerId);
	 
	  public Buyer updateById(Buyer buyer);

	 public Optional<Buyer> getBuyerById(int id);
	 
	// Person updateAddr(Person person);

	
	
}
