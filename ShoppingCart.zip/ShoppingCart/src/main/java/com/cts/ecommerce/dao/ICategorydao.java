package com.cts.ecommerce.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cts.ecommerce.entity.Category;

@Repository
public interface ICategorydao extends JpaRepository<Category, Integer>{

}
