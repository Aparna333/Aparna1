package com.cts.ecommerce.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;


@Entity
public class PurchaseHistory implements Serializable {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int purchaseId;
	private int buyerId;
	private int sellerId;
	@Column(name="treas_id")
	private int transactionId;
	private int itenId;
	@Column(name="no_items")
	private int numberOfItems;
	@Column(name="Date_Time")
	private Date dateTime;
	private int remarks;
	
	public PurchaseHistory() {
		
	}

	public PurchaseHistory(int purchaseId, int buyerId, int sellerId, int transactionId, int itenId, int numberOfItems,
			Date dateTime, int remarks) {
		super();
		this.purchaseId = purchaseId;
		this.buyerId = buyerId;
		this.sellerId = sellerId;
		this.transactionId = transactionId;
		this.itenId = itenId;
		this.numberOfItems = numberOfItems;
		this.dateTime = dateTime;
		this.remarks = remarks;
	}

	public int getPurchaseId() {
		return purchaseId;
	}

	public void setPurchaseId(int purchaseId) {
		this.purchaseId = purchaseId;
	}

	public int getBuyerId() {
		return buyerId;
	}

	public void setBuyerId(int buyerId) {
		this.buyerId = buyerId;
	}

	public int getSellerId() {
		return sellerId;
	}

	public void setSellerId(int sellerId) {
		this.sellerId = sellerId;
	}

	public int getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}

	public int getItenId() {
		return itenId;
	}

	public void setItenId(int itenId) {
		this.itenId = itenId;
	}

	public int getNumberOfItems() {
		return numberOfItems;
	}

	public void setNumberOfItems(int numberOfItems) {
		this.numberOfItems = numberOfItems;
	}

	public Date getDateTime() {
		return dateTime;
	}

	public void setDateTime(Date dateTime) {
		this.dateTime = dateTime;
	}

	public int getRemarks() {
		return remarks;
	}

	public void setRemarks(int remarks) {
		this.remarks = remarks;
	}

	@Override
	public String toString() {
		return "PurchaseHistory [purchaseId=" + purchaseId + ", buyerId=" + buyerId + ", sellerId=" + sellerId
				+ ", transactionId=" + transactionId + ", itenId=" + itenId + ", numberOfItems=" + numberOfItems
				+ ", dateTime=" + dateTime + ", remarks=" + remarks + "]";
	}
	

}
