package com.cts.ecommerce.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Seller implements Serializable{
	 
	@Id
	@GeneratedValue
	private int sellerId;
	@Column(name="seller_name")
	private String sellerUserName;
	private String password;
	private String companyName;
	@Column(name="GST")
	private int gstIN;
	@Column(name="comp_dtls")
	private String companyDetails;
	@Column(name="post_addr")
	private String postalAddress;
	private String website;
	private String email;
	@Column(name="con_number")
	private int contactNumber;
	 
	public Seller() {
		// TODO Auto-generated constructor stub
	}

	public Seller(int sellerId, String sellerUserName, String password, String companyName, int gstIN,
			String companyDetails, String postalAddress, String website, String email, int contactNumber) {
		super();
		this.sellerId = sellerId;
		this.sellerUserName = sellerUserName;
		this.password = password;
		this.companyName = companyName;
		this.gstIN = gstIN;
		this.companyDetails = companyDetails;
		this.postalAddress = postalAddress;
		this.website = website;
		this.email = email;
		this.contactNumber = contactNumber;
	}

	public int getSellerId() {
		return sellerId;
	}

	public void setSellerId(int sellerId) {
		this.sellerId = sellerId;
	}

	public String getSellerUserName() {
		return sellerUserName;
	}

	public void setSellerUserName(String sellerUserName) {
		this.sellerUserName = sellerUserName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public int getGstIN() {
		return gstIN;
	}

	public void setGstIN(int gstIN) {
		this.gstIN = gstIN;
	}

	public String getCompanyDetails() {
		return companyDetails;
	}

	public void setCompanyDetails(String companyDetails) {
		this.companyDetails = companyDetails;
	}

	public String getPostalAddress() {
		return postalAddress;
	}

	public void setPostalAddress(String postalAddress) {
		this.postalAddress = postalAddress;
	}

	public String getWebsite() {
		return website;
	}

	public void setWebsite(String website) {
		this.website = website;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(int contactNumber) {
		this.contactNumber = contactNumber;
	}

	@Override
	public String toString() {
		return "Seller [sellerId=" + sellerId + ", sellerUserName=" + sellerUserName + ", password=" + password
				+ ", companyName=" + companyName + ", gstIN=" + gstIN + ", companyDetails=" + companyDetails
				+ ", postalAddress=" + postalAddress + ", website=" + website + ", email=" + email + ", contactNumber="
				+ contactNumber + "]";
	}
	

}
