package com.cts.ecommerce.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import com.cts.ecommerce.dao.IBuyerdao;
import com.cts.ecommerce.entity.Buyer;
import com.cts.ecommerce.entity.Person;

public class BuyerServiceImpl implements IBuyerService{
     
	@Autowired
	private IBuyerdao dao;
	@Override
	public List<Buyer> getAllBuyers() {
		// TODO Auto-generated method stub
		return dao.findAll();
	}

	@Override
	public Buyer getByBuyerName(String name) {
		
		return dao.findByBuyerName(name);
	}

	@Override
	public Integer createOrUpdate(Buyer buyer) {
		Buyer buyer1 =(Buyer)dao.save(buyer);
		return buyer1.getBuyerId();
		
	}

	@Override
	public void deleteById(Integer buyerId) {
        Optional<Buyer> buyer = dao.findById(buyerId);
		
		if(buyer.isPresent()) {
		dao.deleteById(buyerId);
		}
	}

	@Override
	public Buyer updateById(Buyer buyer) {
		Optional<Buyer> buyer1 = dao.findById(buyer.getBuyerId());
		Buyer b=null;
		if(buyer1.isPresent()) {
			b = buyer1.get();
			b.setUserName(buyer.getUserName());
			b.setEmail(buyer.getEmail());
			b.setPassword(buyer.getPassword());
			b.setEmail(buyer.getEmail());
			b.setMobileNumber(buyer.getMobileNumber());
			b.setDateTime(buyer.getDateTime());
			b = dao.save(b);
		}
		return b;
	}

	@Override
	public Optional<Buyer> getBuyerById(int id) {
		
		return dao.findById(id);
	}

}
