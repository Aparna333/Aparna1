package com.cts.ecommerce.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Transactions implements Serializable{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="trans_id")
	private int transactionId;
	private int userId;
    private int sellerId;
    @Column(name="trans_type")
    private String transactionType;
    @Column(name="Date_Time")
    private Date dateTime;
    private String remarks;
    
    public Transactions() {
		// TODO Auto-generated constructor stub
	}

	public Transactions(int transactionId, int userId, int sellerId, String transactionType, Date dateTime,
			String remarks) {
		super();
		this.transactionId = transactionId;
		this.userId = userId;
		this.sellerId = sellerId;
		this.transactionType = transactionType;
		this.dateTime = dateTime;
		this.remarks = remarks;
	}

	public int getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public int getSellerId() {
		return sellerId;
	}

	public void setSellerId(int sellerId) {
		this.sellerId = sellerId;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public Date getDateTime() {
		return dateTime;
	}

	public void setDateTime(Date dateTime) {
		this.dateTime = dateTime;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	@Override
	public String toString() {
		return "Transactions [transactionId=" + transactionId + ", userId=" + userId + ", sellerId=" + sellerId
				+ ", transactionType=" + transactionType + ", dateTime=" + dateTime + ", remarks=" + remarks + "]";
	}
    
    
}
