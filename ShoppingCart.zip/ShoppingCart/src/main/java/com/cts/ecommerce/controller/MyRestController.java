package com.cts.ecommerce.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cts.ecommerce.entity.Buyer;
import com.cts.ecommerce.service.IBuyerService;

@RestController
public class MyRestController {
	
	@Autowired
	private IBuyerService service;
	
	@RequestMapping("getAll")
	public List<Buyer> getAll(){
		
		return service.getAllBuyers();
	}
	
	@RequestMapping("getByName/{ename}")
	public Buyer getBuyerByName(@PathVariable("ename") String name){
		
		return service.getByBuyerName(name);
	}
	@RequestMapping("getById/{id}")
	public Optional<Buyer> getById(@PathVariable("id") int id){
		
		return service.getBuyerById(id);
	}
	
	@RequestMapping(value = "/buyer", method = RequestMethod.POST, produces = "application/json")
	public Integer createOrUpdate (@RequestBody Buyer buyer) {
		
		return service.createOrUpdate(buyer);
	}
	
	@RequestMapping(value = "deleteById/{pid}", method = RequestMethod.DELETE)
	public void deleteById(@PathVariable("pid") Integer buyerId) {
		
		service.deleteById(buyerId);
	}
	
	@RequestMapping(value="/update", method = RequestMethod.PUT)
	public Buyer updatePerson(@RequestBody Buyer buyer) {
		
		return service.updateById(buyer);
	}
	
}
