package com.cts.ecommerce.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Discounts implements Serializable{
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="disc_id")
	private int discountId;
	@Column(name="disc_code")
	private String discountCode;
	@Column(name="per")
	private float percentage;
	@Column(name="start_Date")
	private Date startDate;
	@Column(name="end_Date")
	private Date endDate;
	@Column(name="desc")
	private String description;
	 
	public Discounts() {
		// TODO Auto-generated constructor stub
	}

	public Discounts(int discountId, String discountCode, float percentage, Date startDate, Date endDate,
			String description) {
		super();
		this.discountId = discountId;
		this.discountCode = discountCode;
		this.percentage = percentage;
		this.startDate = startDate;
		this.endDate = endDate;
		this.description = description;
	}

	public int getDiscountId() {
		return discountId;
	}

	public void setDiscountId(int discountId) {
		this.discountId = discountId;
	}

	public String getDiscountCode() {
		return discountCode;
	}

	public void setDiscountCode(String discountCode) {
		this.discountCode = discountCode;
	}

	public float getPercentage() {
		return percentage;
	}

	public void setPercentage(float percentage) {
		this.percentage = percentage;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public String toString() {
		return "Discounts [discountId=" + discountId + ", discountCode=" + discountCode + ", percentage=" + percentage
				+ ", startDate=" + startDate + ", endDate=" + endDate + ", description=" + description + "]";
	}
	
	

}
