package com.cts;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class ImageServlet extends HttpServlet {
	private PrintWriter Write=null;
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		Write=resp.getWriter();
	    String id=req.getParameter("Fid");
		String name=req.getParameter("Fname");
		String d=req.getParameter("Desc");
		Write.println(id+" "+name+" "+d);
		
	}

}
