package com.cts.maven;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class MyController {
	
	@RequestMapping(value="/", method = RequestMethod.GET)
    public String visitHomePage() {
        return "index";
    }
 
    @RequestMapping(value="/admin", method = RequestMethod.GET)
    public String visitAdministratorPage(ModelMap modelObj) {       
        modelObj.addAttribute("welcome", "Admministrator Control Panel");
        modelObj.addAttribute("message", "This Page Demonstrates How To Use Spring Security!");
        return "admin";
    }
    @RequestMapping(value="/user", method = RequestMethod.GET)
    public String visituserPage(ModelMap model) {
        model.addAttribute("Model", "This is your user page!");
        return "user";
    }

}
